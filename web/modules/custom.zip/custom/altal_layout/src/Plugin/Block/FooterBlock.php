<?php

namespace Drupal\altal_layout\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'Altal Footer' custom block.
 *
 * @Block(
 *   id = "altal_footer_block",
 *   admin_label = @Translation("Altal Footer"),
 *   category = @Translation("Custom")
 * )
 */
class FooterBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#theme' => 'altal_footer',
      '#attached' => [
        'library' => [
          'altal_layout/footer',
        ],
      ],
    ];
  }

}