<?php

namespace Drupal\altal_layout\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides the Altal Header block.
 *
 * @Block(
 *   id = "altal_header_block",
 *   admin_label = @Translation("Altal Header"),
 *   category = @Translation("Altal Layout")
 * )
 */
class HeaderBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#theme'  => 'altal_header',   // we’ll add the Twig template below
      '#cache'  => ['max-age' => 0], // disable caching while developing
    ];
  }

}
